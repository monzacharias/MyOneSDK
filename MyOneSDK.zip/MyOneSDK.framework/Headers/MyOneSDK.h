//
//  MyOneSDK.h
//  MyOneSDK
//
//  Created by Mon Zacharias on 27/10/2017.
//  Copyright © 2017 Mon Zacharias. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyOneSDK.
FOUNDATION_EXPORT double MyOneSDKVersionNumber;

//! Project version string for MyOneSDK.
FOUNDATION_EXPORT const unsigned char MyOneSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyOneSDK/PublicHeader.h>


